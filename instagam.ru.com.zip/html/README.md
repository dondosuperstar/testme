Need to get ssl certificate for your domain

In index.php:
In line 8, replace with your current for the bot.
In line 225, get and insert your link for tracking VK(service http://vboro.de).



In ./bot/index.php:
In line 3, replace with your current for the bot.
In line 5, replace with your domain name (example: test.test).
In line 7, replace the id of the users who need to give access to the bot.
In lines 9 and 10, insert your initial apical and pass for bitly.
In line 11 insert your url.


You also need to install composer and add support for "UA Parser\Parser"
