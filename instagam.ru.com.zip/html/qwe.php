<?php
echo exec("/usr/sbin/ifconfig | grep 2001 | awk '{print $2}'");
//echo $qwe;
echo "qweqweqwe";
?>
