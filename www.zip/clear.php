<?php
unlink('log.txt')
?>	